// TODO: Remove this file once every `classNames` is imported from `@calcom/lib`
export { default } from "@calcom/lib/classNames";
