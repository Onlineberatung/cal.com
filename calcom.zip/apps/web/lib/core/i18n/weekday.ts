export * from "@calcom/lib/weekday";
