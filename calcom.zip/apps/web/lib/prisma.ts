export { default } from "@calcom/prisma";
