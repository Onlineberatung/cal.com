import { expect, test } from "@playwright/test";

import { todo } from "./lib/testUtils";

test.describe("Trial account tests", () => {
  todo("Add tests with a TRIAL account");
});
