export enum TimeZoneEnum {
  USA = "America/Phoenix",
  UK = "Europe/London",
}
