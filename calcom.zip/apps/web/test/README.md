# Unit and Integration Tests

Make sure you have copied .env.test.example to .env.test

You can run all jest tests as

`yarn test`

You can run tests matching specific description by following command
`yarn test -t getSchedule`

Tip: Use `--watchAll` flag to run tests on every change
