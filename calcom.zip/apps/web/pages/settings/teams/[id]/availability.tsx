export { default } from "@calcom/features/ee/teams/pages/availability";
