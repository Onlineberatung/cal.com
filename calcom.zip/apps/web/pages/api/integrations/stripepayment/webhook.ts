export { default, config } from "@calcom/features/ee/payments/api/webhook";
