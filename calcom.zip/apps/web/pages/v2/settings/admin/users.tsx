import { getLayout } from "@calcom/ui/v2/layouts/AdminLayout";

function AdminUsersView() {
  return (
    <>
      <h1>Users listing</h1>
    </>
  );
}

AdminUsersView.getLayout = getLayout;

export default AdminUsersView;
