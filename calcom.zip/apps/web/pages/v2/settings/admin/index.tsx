import { getLayout } from "@calcom/ui/v2/layouts/AdminLayout";

function AdminAppsView() {
  return (
    <>
      <h1>Admin index</h1>
    </>
  );
}

AdminAppsView.getLayout = getLayout;

export default AdminAppsView;
